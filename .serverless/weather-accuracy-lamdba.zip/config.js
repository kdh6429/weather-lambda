module.exports = {
    aws_local_config : {

    },
    aws_remote_config: {
        accessKeyId : 'AKIAU7DMJYSYHGLCL662',
        secretAccessKey : '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',
        region: 'ap-northeast-2'
    },
    map_infos: [
        {name : "서울",     x: "60",	y: "127", midTa: "11B10101", midLand: "11B00000"},
        {name : "강원춘천",  x: "73",	 y: "134", midTa: "11D10301", midLand: "11D10000"},
        {name : "강원강릉",  x: "92",	 y: "131", midTa: "11D20501", midLand: "11D20000"},
        {name : "대전서구",  x: "67",	 y: "100", midTa: "11C20401", midLand: "11C20000"},
        {name : "충청청주",  x: "69",	 y: "106", midTa: "11C10301", midLand: "11C10000"},
        {name : "광주서구",  x: "59",	 y: "74",  midTa: "11F20501", midLand: "11F20000"},
        {name : "전북전주",  x: "63",	 y: "89",  midTa: "11F10201", midLand: "11F10000"},
        {name : "대구중구",  x: "89",	 y: "90",  midTa: "11H10701", midLand: "11H10000"},
        {name : "부산연제",  x: "98",	 y: "76",  midTa: "11H20201", midLand: "11H10000"},
        {name : "제주",     x: "53",	y: "38",  midTa: "11G00201", midLand: "11G00000"},
    ]
}